package io.github.tpfinalassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;


public class SeeRecord extends AppCompatActivity implements View.OnClickListener {


    private ListView listView;
    private UserDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_record);
        listView = (ListView) findViewById(R.id.itemsListView);

        db = new UserDB(this);
        updateDisplay();

    }

    private void updateDisplay(){

        ArrayList<HashMap<String, String>> data = db.getUsers();

        int resource = R.layout.listview_item;
        String[] from = {"Name","DOB", "Weight", "Calories", "CheckFeeling"};
        int[] to = {R.id.txtName,R.id.txtDOB, R.id.txtWeight, R.id.txtCalories,R.id.chkFeeling};


        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        listView.setAdapter(adapter);

    }

    @Override
    public void onClick(View view) {

    }
}
