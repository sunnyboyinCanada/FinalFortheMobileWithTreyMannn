package io.github.tpfinalassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class AddRecord extends AppCompatActivity implements View.OnClickListener{
    private Button vWeightInsert;
    private UserDB db;
    Button   Submit;
    EditText Name;
    EditText DOB;
    EditText Weight;
    EditText Calories;
    Boolean Feeling;
    String sWeight;
    Integer iWeight;
    String sCalories;
    Integer iCalories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_record);

        db = new UserDB(this);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menu_Add:
                startActivity(new Intent(getApplicationContext(), AddRecord.class));
                return true;
            case R.id.menu_Home:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                return true;
            case R.id.menu_Records:
                startActivity(new Intent(getApplicationContext(), SeeRecord.class));
              return true;
//            case R.id.menu_Settings:
//
//                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onClick(View v) {
        Name = findViewById(R.id.txtName);
        DOB = findViewById(R.id.txtDOB);
        Weight = findViewById(R.id.txtWeight);
        sWeight = Weight.getText().toString();
        iWeight = Integer.parseInt(sWeight);
        Calories = findViewById(R.id.txtCalories);
        sCalories = Calories.getText().toString();
        Feeling = ((CheckBox) findViewById(R.id.chkFeeling)).isChecked();
        iCalories = Integer.parseInt(sCalories);
        Submit = findViewById(R.id.btnSubmit);

        db.insertWeight(Name.getText().toString(), DOB.getText().toString(), iWeight, iCalories ,Feeling);
        Toast.makeText(getApplicationContext(), "Added successfully!", Toast.LENGTH_SHORT).show();


    }

}