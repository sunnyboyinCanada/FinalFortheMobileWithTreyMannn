package io.github.tpfinalassignment;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

public class UserDB {
    // database constants
    public static final String DB_NAME = "user.sqlite";
    public static final int    DB_VERSION = 1;


    private static class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // create tables
            db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL ," +
                    " name VARCHAR NOT NULL  , DOB DATE NOT NULL, weight INTEGER NOT NULL DEFAULT 0," +
                    " calories INTEGER NOT NULL DEFAULT 0, feeling BOOLEAN)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db,
                              int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE \"weights\"");
            Log.d("Task list", "Upgrading db from version "
                    + oldVersion + " to " + newVersion);

            onCreate(db);
        }
    }

    // database and database helper objects
    private SQLiteDatabase db;
    private DBHelper dbHelper;

    // constructor
    public UserDB(Context context) {
        dbHelper = new DBHelper(context, DB_NAME, null, DB_VERSION);
        openWriteableDB();
        closeDB();
    }
    // private methods
    private void openReadableDB() {
        db = dbHelper.getReadableDatabase();
    }

    private void openWriteableDB() {
        db = dbHelper.getWritableDatabase();
    }

    private void closeDB() {
        if (db != null)
            db.close();
    }

    ArrayList<HashMap<String, String>> getUsers(){
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        openReadableDB();
        Cursor cursor = db.rawQuery("SELECT name, DOB, weight, calories ,feeling FROM weights",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("name", cursor.getString(0));
            map.put("DOB", cursor.getString(1));
            map.put("weight", cursor.getString(2));
            map.put("calories", cursor.getString(3));
            map.put("feeling", cursor.getString(4));
            data.add(map);
        }

        return data;
    }
    void insertWeight(String vName, String vDOB, Integer vWeight,  Integer vCalories ,Boolean vFeeling){
        openWriteableDB();
        db.execSQL("INSERT INTO weights(name, DOB, weight, calories, feeling) VALUES( " + "'" + vName + "'"
                + ", " + "'" + vDOB + "'" + ", " + "'" + vWeight + "'" + ", " + "'" + vCalories + "'"
                +  ", " + "'" + vFeeling + "'" + ")");
    }
}
